import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Database:
    def __init__(self, db_name=None):
        self.db_name = db_name or os.path.join(BASE_DIR, 'steganography.db')
        self.init_db()

    def _connect(self):
        return sqlite3.connect(self.db_name, timeout=10)

    def init_db(self):
        conn = self._connect()
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Failed attempts table for security notifications
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS failed_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                ip_address TEXT,
                attempt_type TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')

        # Encryption records table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS encryption_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                operation_type TEXT,
                original_filename TEXT,
                output_filename TEXT,
                key_hash TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                blockchain_hash TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')

        conn.commit()
        conn.close()

    def create_user(self, username, email, password, role='user'):
        conn = self._connect()
        cursor = conn.cursor()
        password_hash = generate_password_hash(password)
        try:
            cursor.execute('''
                INSERT INTO users (username, email, password, role)
                VALUES (?, ?, ?, ?)
            ''', (username, email, password_hash, role))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()

    def authenticate_user(self, username, password):
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, role, password FROM users WHERE username = ?',
                       (username,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user[3], password):
            return {'id': user[0], 'username': user[1], 'role': user[2]}
        return None

    def log_failed_attempt(self, user_id, username, ip_address, attempt_type):
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO failed_attempts (user_id, username, ip_address, attempt_type)
            VALUES (?, ?, ?, ?)
        ''', (user_id, username, ip_address, attempt_type))
        conn.commit()
        conn.close()

    def get_failed_attempts(self):
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM failed_attempts ORDER BY timestamp DESC, id DESC')
        attempts = cursor.fetchall()
        conn.close()
        return attempts

    def save_encryption_record(self, user_id, operation_type, original_filename,
                               output_filename, key_hash, blockchain_hash):
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO encryption_records
            (user_id, operation_type, original_filename, output_filename, key_hash, blockchain_hash)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, operation_type, original_filename, output_filename, key_hash, blockchain_hash))
        conn.commit()
        conn.close()

    def get_user_records(self, user_id):
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM encryption_records
            WHERE user_id = ? ORDER BY timestamp DESC, id DESC
        ''', (user_id,))
        records = cursor.fetchall()
        conn.close()
        return records

    def get_all_records(self):
        # Columns 0-7 = encryption_records, column 8 = username
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT er.*, u.username
            FROM encryption_records er
            JOIN users u ON er.user_id = u.id
            ORDER BY er.timestamp DESC, er.id DESC
        ''')
        records = cursor.fetchall()
        conn.close()
        return records
