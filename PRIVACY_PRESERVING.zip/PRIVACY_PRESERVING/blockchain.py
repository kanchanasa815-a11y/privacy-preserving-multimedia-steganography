import hashlib
import json
import os
import threading
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
CHAIN_FILE = os.path.join(BASE_DIR, 'blockchain.json')


class Block:
    def __init__(self, index, timestamp, data, previous_hash, hash_value=None):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        # When loading from disk we keep the stored hash so tampering is detectable.
        self.hash = hash_value if hash_value is not None else self.calculate_hash()

    def calculate_hash(self):
        block_string = json.dumps({
            "index": self.index,
            "timestamp": self.timestamp,
            "data": self.data,
            "previous_hash": self.previous_hash
        }, sort_keys=True)
        return hashlib.sha256(block_string.encode()).hexdigest()

    def to_dict(self):
        return {
            'index': self.index,
            'timestamp': self.timestamp,
            'data': self.data,
            'hash': self.hash,
            'previous_hash': self.previous_hash
        }


class Blockchain:
    def __init__(self, chain_file=CHAIN_FILE):
        self.chain_file = chain_file
        self._lock = threading.Lock()
        self.chain = self._load() or [self.create_genesis_block()]
        self._save()

    # ---- persistence (so the chain survives restarts, like the SQL records) ----
    def _load(self):
        if not os.path.exists(self.chain_file):
            return None
        try:
            with open(self.chain_file, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            chain = [Block(b['index'], b['timestamp'], b['data'],
                           b['previous_hash'], b['hash']) for b in raw]
            return chain or None
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _save(self):
        try:
            tmp = self.chain_file + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump([b.to_dict() for b in self.chain], f, indent=2)
            os.replace(tmp, self.chain_file)
        except OSError:
            pass  # persistence is best-effort; the in-memory chain still works

    def create_genesis_block(self):
        return Block(0, datetime.now().isoformat(), "Genesis Block", "0")

    def get_latest_block(self):
        return self.chain[-1]

    def add_block(self, data):
        with self._lock:
            previous_block = self.get_latest_block()
            new_block = Block(
                index=len(self.chain),
                timestamp=datetime.now().isoformat(),
                data=data,
                previous_hash=previous_block.hash
            )
            self.chain.append(new_block)
            self._save()
            return new_block.hash

    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i - 1]
            if current_block.hash != current_block.calculate_hash():
                return False
            if current_block.previous_hash != previous_block.hash:
                return False
        return True

    def get_chain_data(self):
        return [block.to_dict() for block in self.chain]


# Global blockchain instance
blockchain = Blockchain()
