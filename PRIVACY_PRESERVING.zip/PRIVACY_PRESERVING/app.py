import base64
import hashlib
import os
import secrets
import uuid
from datetime import datetime
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for, session,
                   flash, jsonify, send_from_directory)
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.utils import secure_filename

from blockchain import blockchain
from crypto_utils import (StegoError, SteganographyCrypto, TextSteganography,
                          ImageSteganography, AudioSteganography, VideoSteganography)
from database import Database

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def _load_secret_key():
    """Use SECRET_KEY from the environment, otherwise create one once and reuse it."""
    env_key = os.environ.get('SECRET_KEY')
    if env_key:
        return env_key
    key_file = os.path.join(BASE_DIR, '.secret_key')
    try:
        with open(key_file, 'r') as f:
            key = f.read().strip()
            if key:
                return key
    except OSError:
        pass
    key = secrets.token_hex(32)
    try:
        with open(key_file, 'w') as f:
            f.write(key)
    except OSError:
        pass
    return key


app = Flask(__name__)
app.secret_key = _load_secret_key()
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 256 * 1024 * 1024  # 256 MB per request (video needs room)

db = Database()

# Create the admin user once (change the password after first login / via ADMIN_PASSWORD).
if db.create_user('admin', 'admin@securestegano.com',
                  os.environ.get('ADMIN_PASSWORD', 'admin123'), 'admin'):
    print("Admin user created (username: admin).")

IMAGE_EXTS = {'png', 'jpg', 'jpeg', 'bmp'}
AUDIO_EXTS = {'wav', 'mp3', 'ogg', 'flac', 'm4a', 'aac'}
VIDEO_EXTS = {'mp4', 'avi', 'mov', 'mkv', 'webm'}
BROWSER_VIDEO_EXTS = {'mp4', 'webm'}      # formats a browser <video> tag can preview


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return view(*args, **kwargs)
    return wrapper


def file_ext(filename):
    return filename.rsplit('.', 1)[1].lower() if filename and '.' in filename else ''


def valid_upload(file, allowed):
    return bool(file and file.filename and file_ext(file.filename) in allowed)


def display_name(file):
    return secure_filename(file.filename) or 'upload'


def save_upload(file, prefix):
    """Save an upload under a unique name and return its path."""
    stored = f"{prefix}_{session['user_id']}_{uuid.uuid4().hex[:10]}.{file_ext(file.filename)}"
    path = os.path.join(UPLOAD_FOLDER, stored)
    file.save(path)
    return path


def new_output_name(prefix, ext):
    return f"{prefix}_{session['user_id']}_{uuid.uuid4().hex[:10]}.{ext}"


def upload_path(name):
    return os.path.join(UPLOAD_FOLDER, name)


def remove_files(*paths):
    for p in paths:
        if p:
            try:
                os.remove(p)
            except OSError:
                pass


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def new_key():
    key = SteganographyCrypto.generate_key()
    return key, base64.b64encode(key).decode()


def record_operation(operation, original_label, output_name, key_b64, extra=None):
    """Write the operation to the blockchain and to the SQL record table."""
    block_data = {
        'user_id': session['user_id'],
        'operation': operation,
        'original_file': original_label,
        'output_file': output_name,
        'output_sha256': sha256_file(upload_path(output_name)),
        'timestamp': datetime.now().isoformat(),
    }
    if extra:
        block_data.update(extra)
    blockchain_hash = blockchain.add_block(block_data)
    key_hash = hashlib.sha256(key_b64.encode()).hexdigest()
    db.save_encryption_record(session['user_id'], operation, original_label,
                              output_name, key_hash, blockchain_hash)


def log_failed_decryption():
    db.log_failed_attempt(session.get('user_id'), session.get('username'),
                          request.remote_addr, 'decryption')


def safe_run(fn, *args, decrypting=False):
    """Run an operation; show a friendly flash message instead of crashing."""
    try:
        return True, fn(*args)
    except StegoError as e:
        if decrypting:
            log_failed_decryption()
        flash(str(e), 'error')
    except Exception:
        app.logger.exception('Operation failed')
        if decrypting:
            log_failed_decryption()
        flash('Could not process the files. Make sure they are valid and not corrupted.', 'error')
    return False, None


# --------------------------------------------------------------------------- #
# Public / auth pages
# --------------------------------------------------------------------------- #
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')

        if not username or not email or not password:
            flash('All fields are required.', 'error')
        elif len(password) < 6:
            flash('Password must be at least 6 characters.', 'error')
        elif db.create_user(username, email, password):
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Username or email already exists!', 'error')

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = db.authenticate_user(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))

        db.log_failed_attempt(None, username, request.remote_addr, 'login')
        flash('Invalid credentials!', 'error')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


@app.route('/dashboard')
@login_required
def dashboard():
    records = db.get_user_records(session['user_id'])
    counts = {kind: sum(1 for r in records if r[2] == f'{kind}_encryption')
              for kind in ('text', 'image', 'audio', 'video')}
    return render_template('dashboard.html', records=records, counts=counts)


# --------------------------------------------------------------------------- #
# TEXT in IMAGE
# --------------------------------------------------------------------------- #
@app.route('/text-steganography', methods=['GET', 'POST'])
@login_required
def text_steganography():
    ctx = {'active_tab': 'encrypt'}

    if request.method == 'POST':
        operation = request.form.get('operation')

        if operation == 'encrypt':
            text = request.form.get('text', '').strip()
            file = request.files.get('image')
            if not text:
                flash('Please enter the text to hide.', 'error')
            elif not valid_upload(file, IMAGE_EXTS):
                flash('Please choose a PNG, JPG, JPEG or BMP carrier image.', 'error')
            else:
                in_path = save_upload(file, 'in')
                out_name = new_output_name('stego_text', 'png')
                key, key_b64 = new_key()
                ok, _ = safe_run(TextSteganography.hide_text, text, in_path,
                                 upload_path(out_name), key)
                remove_files(in_path)
                if ok:
                    record_operation('text_encryption', display_name(file), out_name, key_b64)
                    ctx.update(key=key_b64, output_file=out_name)

        elif operation == 'decrypt':
            ctx['active_tab'] = 'decrypt'
            file = request.files.get('encrypted_image')
            if not valid_upload(file, IMAGE_EXTS):
                flash('Please choose the stego image (PNG recommended).', 'error')
            else:
                in_path = save_upload(file, 'dec')
                ok, text = safe_run(
                    lambda: TextSteganography.reveal_text(
                        in_path, SteganographyCrypto.parse_key(request.form.get('decryption_key'))),
                    decrypting=True)
                remove_files(in_path)
                if ok:
                    ctx['decrypted_text'] = text

    return render_template('text_steganography.html', **ctx)


# --------------------------------------------------------------------------- #
# IMAGE in IMAGE
# --------------------------------------------------------------------------- #
@app.route('/image-steganography', methods=['GET', 'POST'])
@login_required
def image_steganography():
    ctx = {'active_tab': 'encrypt'}

    if request.method == 'POST':
        operation = request.form.get('operation')

        if operation == 'encrypt':
            carrier = request.files.get('carrier_image')
            hidden = request.files.get('hidden_image')
            if not (valid_upload(carrier, IMAGE_EXTS) and valid_upload(hidden, IMAGE_EXTS)):
                flash('Please choose a PNG, JPG, JPEG or BMP for both images.', 'error')
            else:
                carrier_path = save_upload(carrier, 'carrier')
                hidden_path = save_upload(hidden, 'hidden')
                out_name = new_output_name('stego_img', 'png')
                key, key_b64 = new_key()
                ok, _ = safe_run(ImageSteganography.embed_image_in_image, carrier_path,
                                 hidden_path, upload_path(out_name), key)
                remove_files(carrier_path, hidden_path)
                if ok:
                    record_operation('image_encryption',
                                     f"{display_name(carrier)}+{display_name(hidden)}",
                                     out_name, key_b64)
                    ctx.update(key=key_b64, output_file=out_name)

        elif operation == 'decrypt':
            ctx['active_tab'] = 'decrypt'
            file = request.files.get('encrypted_image')
            if not valid_upload(file, IMAGE_EXTS):
                flash('Please choose the stego image (PNG recommended).', 'error')
            else:
                in_path = save_upload(file, 'dec')

                def extract():
                    key = SteganographyCrypto.parse_key(request.form.get('decryption_key'))
                    img = ImageSteganography.extract_image_from_image(in_path, key)
                    name = new_output_name('extracted_img', 'png')
                    img.convert('RGB').save(upload_path(name), format='PNG')
                    return name

                ok, name = safe_run(extract, decrypting=True)
                remove_files(in_path)
                if ok:
                    ctx['extracted_image'] = name

    return render_template('image_steganography.html', **ctx)


# --------------------------------------------------------------------------- #
# AUDIO in AUDIO
# --------------------------------------------------------------------------- #
@app.route('/audio-steganography', methods=['GET', 'POST'])
@login_required
def audio_steganography():
    ctx = {'active_tab': 'encrypt'}

    if request.method == 'POST':
        operation = request.form.get('operation')

        if operation == 'encrypt':
            carrier = request.files.get('carrier_audio')
            hidden = request.files.get('hidden_audio')
            if not (valid_upload(carrier, AUDIO_EXTS) and valid_upload(hidden, AUDIO_EXTS)):
                flash('Please choose audio files (WAV, MP3, OGG, FLAC, M4A, AAC).', 'error')
            else:
                carrier_path = save_upload(carrier, 'carrier')
                hidden_path = save_upload(hidden, 'hidden')
                converted_path = None
                out_name = new_output_name('stego_audio', 'wav')
                key, key_b64 = new_key()

                def embed():
                    nonlocal converted_path
                    wav_path = carrier_path
                    if file_ext(carrier.filename) != 'wav':
                        converted_path = upload_path(new_output_name('conv', 'wav'))
                        AudioSteganography.convert_to_wav(carrier_path, converted_path)
                        wav_path = converted_path
                    AudioSteganography.embed_audio_in_audio(
                        wav_path, hidden_path, upload_path(out_name), key)

                ok, _ = safe_run(embed)
                remove_files(carrier_path, hidden_path, converted_path)
                if ok:
                    record_operation('audio_encryption',
                                     f"{display_name(carrier)}+{display_name(hidden)}",
                                     out_name, key_b64)
                    ctx.update(key=key_b64, output_file=out_name)

        elif operation == 'decrypt':
            ctx['active_tab'] = 'decrypt'
            file = request.files.get('encrypted_audio')
            if not valid_upload(file, {'wav'}):
                flash('Please choose the stego WAV file that was generated by the Encrypt tab.', 'error')
            else:
                in_path = save_upload(file, 'dec')

                def extract():
                    key = SteganographyCrypto.parse_key(request.form.get('decryption_key'))
                    data, ext = AudioSteganography.extract_audio_from_audio(in_path, key)
                    name = new_output_name('extracted_audio', ext)
                    with open(upload_path(name), 'wb') as f:
                        f.write(data)
                    return name

                ok, name = safe_run(extract, decrypting=True)
                remove_files(in_path)
                if ok:
                    ctx['extracted_audio'] = name

    return render_template('audio_steganography.html', **ctx)


# --------------------------------------------------------------------------- #
# VIDEO in VIDEO
# --------------------------------------------------------------------------- #
@app.route('/video-steganography', methods=['GET', 'POST'])
@login_required
def video_steganography():
    ctx = {'active_tab': 'encrypt', 'browser_video_exts': sorted(BROWSER_VIDEO_EXTS)}

    if request.method == 'POST':
        operation = request.form.get('operation')

        if operation == 'encrypt':
            carrier = request.files.get('carrier_video')
            hidden = request.files.get('hidden_video')
            if not (valid_upload(carrier, VIDEO_EXTS) and valid_upload(hidden, VIDEO_EXTS)):
                flash('Please choose video files (MP4, AVI, MOV, MKV, WEBM).', 'error')
            else:
                carrier_path = save_upload(carrier, 'carrier')
                hidden_path = save_upload(hidden, 'hidden')
                out_name = new_output_name('stego_video', file_ext(carrier.filename))
                key, key_b64 = new_key()
                ok, _ = safe_run(VideoSteganography.embed_video_in_video, carrier_path,
                                 hidden_path, upload_path(out_name), key)
                remove_files(carrier_path, hidden_path)
                if ok:
                    record_operation('video_encryption',
                                     f"{display_name(carrier)}+{display_name(hidden)}",
                                     out_name, key_b64)
                    ctx.update(key=key_b64, output_file=out_name,
                               output_ext=file_ext(out_name))

        elif operation == 'decrypt':
            ctx['active_tab'] = 'decrypt'
            file = request.files.get('encrypted_video')
            if not valid_upload(file, VIDEO_EXTS):
                flash('Please choose the stego video that was generated by the Encrypt tab.', 'error')
            else:
                in_path = save_upload(file, 'dec')

                def extract():
                    key = SteganographyCrypto.parse_key(request.form.get('decryption_key'))
                    data, ext = VideoSteganography.extract_video_from_video(in_path, key)
                    name = new_output_name('extracted_video', ext)
                    with open(upload_path(name), 'wb') as f:
                        f.write(data)
                    return name

                ok, name = safe_run(extract, decrypting=True)
                remove_files(in_path)
                if ok:
                    ctx.update(extracted_video=name, extracted_ext=file_ext(name))

    return render_template('video_steganography.html', **ctx)


# --------------------------------------------------------------------------- #
# Blockchain, admin, files, API
# --------------------------------------------------------------------------- #
@app.route('/blockchain')
@login_required
def blockchain_view():
    return render_template('blockchain_view.html', chain=blockchain.get_chain_data(),
                           chain_valid=blockchain.is_chain_valid())


@app.route('/admin')
@login_required
def admin():
    if session.get('role') != 'admin':
        flash('Access denied!', 'error')
        return redirect(url_for('dashboard'))

    return render_template('admin.html',
                           failed_attempts=db.get_failed_attempts(),
                           records=db.get_all_records(),
                           chain=blockchain.get_chain_data(),
                           chain_valid=blockchain.is_chain_valid())


@app.route('/api/verify-blockchain')
@login_required
def verify_blockchain():
    return jsonify({'valid': blockchain.is_chain_valid(), 'blocks': len(blockchain.chain)})


@app.route('/download/<path:filename>')
@login_required
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)


@app.route('/media/<path:filename>')
@login_required
def media_file(filename):
    """Inline playback/preview (supports HTTP range requests so video seeking works)."""
    return send_from_directory(UPLOAD_FOLDER, filename)


@app.errorhandler(RequestEntityTooLarge)
def too_large(_e):
    flash('Upload too large. The total size of the files must be under 256 MB.', 'error')
    return redirect(request.referrer or url_for('dashboard'))


if __name__ == '__main__':
    app.run(debug=os.environ.get('FLASK_DEBUG') == '1', host='127.0.0.1', port=5000)
