"""
Encryption + steganography engine.

Supported operations
--------------------
* TextSteganography  : hide encrypted text inside an image          (LSB)
* ImageSteganography : hide an encrypted image inside an image      (LSB)
* AudioSteganography : hide an encrypted audio file inside a WAV    (LSB of PCM samples)
* VideoSteganography : hide an encrypted video file inside a video  (container-level embedding)

Every payload is encrypted with AES-128-GCM *before* it is hidden, so a wrong
key or a tampered file is detected cleanly instead of producing garbage.
"""
import base64
import binascii
import io
import os
import re
import shutil
import struct
import subprocess
import wave

import numpy as np
from PIL import Image
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes


class StegoError(ValueError):
    """Raised for any user-facing steganography / crypto problem."""


def _fmt(n):
    if n >= 1024 * 1024:
        return f"{n / (1024 * 1024):.1f} MB"
    if n >= 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n} bytes"


# --------------------------------------------------------------------------- #
# Encryption
# --------------------------------------------------------------------------- #
class SteganographyCrypto:
    KEY_SIZE = 16          # AES-128
    NONCE_SIZE = 12
    TAG_SIZE = 16

    @staticmethod
    def generate_key():
        return get_random_bytes(SteganographyCrypto.KEY_SIZE)

    @staticmethod
    def parse_key(key_b64):
        """Turn the base64 key typed by the user into raw bytes (or raise StegoError)."""
        try:
            key = base64.b64decode((key_b64 or "").strip(), validate=True)
        except (binascii.Error, ValueError):
            raise StegoError("Invalid key format. Paste the key exactly as it was shown.")
        if len(key) != SteganographyCrypto.KEY_SIZE:
            raise StegoError("Invalid key length. Paste the key exactly as it was shown.")
        return key

    @staticmethod
    def encrypt(data, key):
        nonce = get_random_bytes(SteganographyCrypto.NONCE_SIZE)
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(data)
        return nonce + tag + ciphertext

    @staticmethod
    def decrypt(blob, key):
        n, t = SteganographyCrypto.NONCE_SIZE, SteganographyCrypto.TAG_SIZE
        if len(blob) < n + t:
            raise StegoError("Hidden data is corrupted or incomplete.")
        nonce, tag, ciphertext = blob[:n], blob[n:n + t], blob[n + t:]
        try:
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            return cipher.decrypt_and_verify(ciphertext, tag)
        except ValueError:
            raise StegoError("Wrong key, or the file was modified/re-compressed after hiding.")

    # -- store "file bytes + original extension" as one payload --------------- #
    @staticmethod
    def pack_file(data, ext):
        ext = re.sub(r"[^a-z0-9]", "", (ext or "").lower())[:8] or "bin"
        ext_b = ext.encode()
        return struct.pack(">B", len(ext_b)) + ext_b + data

    @staticmethod
    def unpack_file(plain):
        if not plain:
            raise StegoError("Hidden data is empty.")
        ext_len = plain[0]
        if 1 + ext_len > len(plain):
            raise StegoError("Hidden data is corrupted.")
        ext = plain[1:1 + ext_len].decode(errors="ignore")
        ext = re.sub(r"[^a-z0-9]", "", ext.lower())[:8] or "bin"
        return plain[1 + ext_len:], ext


# --------------------------------------------------------------------------- #
# Generic LSB engine (works on any 1-D uint8 numpy array / strided view)
# --------------------------------------------------------------------------- #
class _LSB:
    MAGIC = b"PSTG"
    HEADER_BYTES = 8                      # 4 magic + 4 length
    HEADER_BITS = HEADER_BYTES * 8

    @staticmethod
    def capacity_bytes(carrier):
        return max(0, (carrier.size - _LSB.HEADER_BITS) // 8)

    @staticmethod
    def embed(carrier, blob):
        """Write blob into the least-significant bits of `carrier` (in place)."""
        payload = _LSB.MAGIC + struct.pack(">I", len(blob)) + blob
        bits = np.unpackbits(np.frombuffer(payload, dtype=np.uint8))
        if bits.size > carrier.size:
            raise StegoError(
                "Carrier is too small. The hidden data needs about "
                f"{_fmt(len(blob))} but this carrier can only hold about "
                f"{_fmt(_LSB.capacity_bytes(carrier))}. Use a bigger carrier or a smaller secret."
            )
        carrier[:bits.size] = (carrier[:bits.size] & 0xFE) | bits

    @staticmethod
    def extract(carrier):
        if carrier.size < _LSB.HEADER_BITS:
            raise StegoError("No hidden data found in this file.")
        header = np.packbits(carrier[:_LSB.HEADER_BITS] & 1).tobytes()
        if header[:4] != _LSB.MAGIC:
            raise StegoError(
                "No hidden data found in this file. (Was it saved/converted after hiding? "
                "Only the original stego file works.)"
            )
        length = struct.unpack(">I", header[4:8])[0]
        end = _LSB.HEADER_BITS + length * 8
        if length == 0 or end > carrier.size:
            raise StegoError("Hidden data is corrupted or incomplete.")
        return np.packbits(carrier[_LSB.HEADER_BITS:end] & 1).tobytes()


# --------------------------------------------------------------------------- #
# Image carriers (shared by text + image steganography)
# --------------------------------------------------------------------------- #
class _ImageLSB(SteganographyCrypto):
    @staticmethod
    def _load_rgb_array(path):
        try:
            with Image.open(path) as img:
                return np.array(img.convert("RGB"), dtype=np.uint8)
        except Exception:
            raise StegoError("Could not read this file as an image.")

    @staticmethod
    def embed_data_in_image(image_path, data, output_path):
        """Hide raw bytes in an image. The output is ALWAYS lossless PNG
        (JPEG compression would destroy the hidden bits)."""
        arr = _ImageLSB._load_rgb_array(image_path)
        flat = arr.reshape(-1)                     # view on arr
        _LSB.embed(flat, data)
        Image.fromarray(arr).save(output_path, format="PNG")

    @staticmethod
    def extract_data_from_image(image_path):
        arr = _ImageLSB._load_rgb_array(image_path)
        return _LSB.extract(arr.reshape(-1))


class TextSteganography(_ImageLSB):
    """Text -> encrypted -> hidden inside an image."""

    @staticmethod
    def hide_text(text, image_path, output_path, key):
        blob = TextSteganography.encrypt(text.encode("utf-8"), key)
        TextSteganography.embed_data_in_image(image_path, blob, output_path)

    @staticmethod
    def reveal_text(image_path, key):
        blob = TextSteganography.extract_data_from_image(image_path)
        plain = TextSteganography.decrypt(blob, key)
        try:
            return plain.decode("utf-8")
        except UnicodeDecodeError:
            raise StegoError("The hidden data is not text.")


class ImageSteganography(_ImageLSB):
    """Image -> encrypted -> hidden inside another image."""

    @staticmethod
    def embed_image_in_image(carrier_image_path, hidden_image_path, output_image_path, key):
        hidden = _ImageLSB._load_rgb_array(hidden_image_path)
        buf = io.BytesIO()
        Image.fromarray(hidden).save(buf, format="PNG", optimize=True)
        blob = ImageSteganography.encrypt(buf.getvalue(), key)
        ImageSteganography.embed_data_in_image(carrier_image_path, blob, output_image_path)

    @staticmethod
    def extract_image_from_image(encrypted_image_path, key):
        blob = ImageSteganography.extract_data_from_image(encrypted_image_path)
        plain = ImageSteganography.decrypt(blob, key)
        try:
            img = Image.open(io.BytesIO(plain))
            img.load()
            return img
        except Exception:
            raise StegoError("The hidden data is not a valid image.")


# --------------------------------------------------------------------------- #
# Audio-in-audio  (LSB of PCM samples inside a WAV carrier)
# --------------------------------------------------------------------------- #
class AudioSteganography(SteganographyCrypto):
    @staticmethod
    def convert_to_wav(src_path, dst_path):
        """Convert mp3/ogg/flac/m4a... to 16-bit PCM WAV using ffmpeg (if installed)."""
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            raise StegoError(
                "The carrier must be a WAV file. (Install ffmpeg to use MP3/OGG/FLAC/M4A "
                "carriers - they are converted to WAV automatically.)"
            )
        try:
            result = subprocess.run(
                [ffmpeg, "-y", "-loglevel", "error", "-i", src_path,
                 "-vn", "-acodec", "pcm_s16le", dst_path],
                capture_output=True, timeout=300,
            )
        except subprocess.TimeoutExpired:
            raise StegoError("Converting the carrier audio to WAV took too long.")
        if result.returncode != 0 or not os.path.exists(dst_path):
            raise StegoError("Could not read the carrier audio file.")

    @staticmethod
    def _read_wav(path):
        try:
            with wave.open(path, "rb") as w:
                params = w.getparams()
                frames = w.readframes(w.getnframes())
        except (wave.Error, EOFError):
            raise StegoError(
                "Carrier must be an uncompressed PCM WAV file "
                "(re-export as 16-bit PCM WAV if it is float/compressed)."
            )
        if params.comptype != "NONE":
            raise StegoError("Carrier must be an uncompressed PCM WAV file.")
        return params, frames

    @staticmethod
    def embed_audio_in_audio(carrier_wav_path, hidden_audio_path, output_wav_path, key):
        params, frames = AudioSteganography._read_wav(carrier_wav_path)
        sw = params.sampwidth
        arr = np.frombuffer(frames, dtype=np.uint8).copy()
        lsb_view = arr[0::sw]            # least-significant byte of each (little-endian) sample

        with open(hidden_audio_path, "rb") as f:
            hidden = f.read()
        if not hidden:
            raise StegoError("The audio file to hide is empty.")
        ext = os.path.splitext(hidden_audio_path)[1].lstrip(".")

        blob = AudioSteganography.encrypt(AudioSteganography.pack_file(hidden, ext), key)
        _LSB.embed(lsb_view, blob)

        with wave.open(output_wav_path, "wb") as out:
            out.setnchannels(params.nchannels)
            out.setsampwidth(sw)
            out.setframerate(params.framerate)
            out.writeframes(arr.tobytes())

    @staticmethod
    def extract_audio_from_audio(stego_wav_path, key):
        """Returns (audio_bytes, original_extension)."""
        params, frames = AudioSteganography._read_wav(stego_wav_path)
        arr = np.frombuffer(frames, dtype=np.uint8)
        blob = _LSB.extract(arr[0::params.sampwidth])
        plain = AudioSteganography.decrypt(blob, key)
        return AudioSteganography.unpack_file(plain)


# --------------------------------------------------------------------------- #
# Video-in-video  (encrypted payload embedded inside the carrier's container)
# --------------------------------------------------------------------------- #
class VideoSteganography(SteganographyCrypto):
    """
    Pixel-LSB cannot survive video codecs (H.264/VP9 re-quantise every frame), so
    the hidden video is encrypted and embedded at container level:

        [ original carrier video bytes ][ encrypted payload ][ 16-byte footer ]

    * The carrier still plays normally in every player (its bytes are untouched).
    * For MP4/MOV the payload is wrapped in a standard 'free' box, so the file
      stays a perfectly valid MP4.
    * The hidden video is recovered bit-for-bit, any size, no quality loss.
    """
    FOOTER_MAGIC = b"PSTGVID1"
    FOOTER_BYTES = 16                               # 8 length + 8 magic
    MP4_LIKE = {"mp4", "m4v", "mov"}

    @staticmethod
    def embed_video_in_video(carrier_path, hidden_path, output_path, key):
        with open(hidden_path, "rb") as f:
            hidden = f.read()
        if not hidden:
            raise StegoError("The video to hide is empty.")
        hidden_ext = os.path.splitext(hidden_path)[1].lstrip(".")
        carrier_ext = os.path.splitext(carrier_path)[1].lstrip(".").lower()

        blob = VideoSteganography.encrypt(VideoSteganography.pack_file(hidden, hidden_ext), key)
        footer = struct.pack(">Q", len(blob)) + VideoSteganography.FOOTER_MAGIC
        tail = blob + footer

        wrap_in_box = carrier_ext in VideoSteganography.MP4_LIKE
        if wrap_in_box and 8 + len(tail) >= 2 ** 32:
            raise StegoError("Hidden video is too large for an MP4 carrier (max ~4 GB).")

        with open(output_path, "wb") as out:
            with open(carrier_path, "rb") as src:
                shutil.copyfileobj(src, out, 1024 * 1024)
            if wrap_in_box:
                out.write(struct.pack(">I4s", 8 + len(tail), b"free"))
            out.write(tail)

    @staticmethod
    def extract_video_from_video(stego_path, key):
        """Returns (video_bytes, original_extension)."""
        fb = VideoSteganography.FOOTER_BYTES
        size = os.path.getsize(stego_path)
        if size < fb + SteganographyCrypto.NONCE_SIZE + SteganographyCrypto.TAG_SIZE:
            raise StegoError("No hidden video found in this file.")
        with open(stego_path, "rb") as f:
            f.seek(-fb, os.SEEK_END)
            footer = f.read(fb)
            if footer[8:] != VideoSteganography.FOOTER_MAGIC:
                raise StegoError(
                    "No hidden video found in this file. (Use the exact stego video that was "
                    "downloaded - re-encoding or re-uploading it removes the hidden data.)"
                )
            length = struct.unpack(">Q", footer[:8])[0]
            if length + fb > size:
                raise StegoError("Hidden video data is corrupted or incomplete.")
            f.seek(-(fb + length), os.SEEK_END)
            blob = f.read(length)
        plain = VideoSteganography.decrypt(blob, key)
        return VideoSteganography.unpack_file(plain)
